/**
 * 
 */
/**
 * The JUnit parameters setup
 * @author IRiley
 *
 */
package com.gmail.test.testPrep;