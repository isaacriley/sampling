/**
 * 
 */
/**
 * Houses the page object for the mailbox & its accompaniments
 * @author IRiley
 *
 */
package com.gmail.pageObjects.mailbox;