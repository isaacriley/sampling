/**
 * 
 */
package com.gmail.pageObjects;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpHead;
import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.ScreenshotException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gmail.util.AutomationHelper;

/**
 * <pre>This class forms the basis for the Page Object Model (POM) pattern</pre>
 * This is the base class for the Page Object Model. Each page and its 
 * accompanying page object will inevitably inherit/extend this base class.
 *
 * I have omitted some of the code, this can be a rather sizeable class -- you'd be surprised 
 * what the individual page objects have in common.
 * 
 * @author IRiley
 *
 */
public abstract class BasePage {
	
	public Object NOBODY ="Widget is not present";
	
	protected WebDriver driver;
	//assuming that each page has its own unique title
	private String pageTitle;
	protected String URL;
	//for concurrency purposes, we need re-entrant locks
	protected final ReentrantReadWriteLock readWriteLock = new ReentrantReadWriteLock();
	/*
	 * How long to wait for widget, we chose 75 seconds -- Google recommends  having a timeout that is greater 
	 * than the socket timeout of 45 seconds. The TCT enhancements grid refresh is very slow
	 */
	private long WAIT_TIME =75; 
	private long POLL_TIME =5;
	//private static final long EXPLICIT_TIMEOUT =30000;//30 seconds
	private static final long IMPL_WAIT = 10; //10 seconds
	
	/**
	 * Each page object has its own WebDriver (for the purposes of manipulating and integrating with itself)
	 * @param driver crawling the page
	 */
	public BasePage(WebDriver driver){
		this.driver = driver;
	}
	
	/**
	 * If the page's title is unique, you may use this constructor
	 * @param driver crawling the page
	 * @param pageTitle the page's title
	 */
	public BasePage(WebDriver driver, String pageTitle){
		this.driver = driver;
		this.pageTitle = pageTitle;
	}
	
	/**
	 * We allow each page object to decide on how it wants to open itself 
	 * @param driver crawling the page
	 */
	public abstract void openPage(WebDriver driver);
	
	/**
	 * Each page object has the ability to either open its own page and another page for that
	 * @param driver crawling the page
	 * @param url URL to open
	 * @return reference to the {@link WebDriver} that will be used at the target
	 */
	protected WebDriver openURL(WebDriver driver, String url){
		try{
			driver.get(url);
			return driver;
		}catch(Exception e){
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
		}
		return driver;//give back driver as is
	}
	
		
	/**
	 * Wait for element/widget to be present (in the DOM)
	  * @param driver WebDriver that's crawling the page
	 * @param by the selector (XPath or CSS) to get at the widget
	 * @return reference to the {@link WebElement} widget , or null if there is no reference to a widget
	 * <p>
	 * 	 Note: I could have used a Null object design pattern or throw an exception but I'm simplifying the
	 * 		   method's usage. Besides, we want the test case to fail immediately if the widget isn't found.
	 * </p>
	 */
	protected WebElement waitForPresenceOfWidget(WebDriver driver, By by){
		WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME, POLL_TIME);
		try{
			WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(by));
		return element;
		}catch(Exception e){
			AutomationHelper.writeToLogsAsIs("\n***Failed to interact with Widget identified by"
					+ "\n\tSelector: "+by.toString()+"***");
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
		}//catch
		return null; //if all fails
	}
	
	/**
	 * Find the widget on the page
	 * @param driver crawling the page
	 * @param by the XPATH or CSS locator to get to the widget
	 * @return reference to the {@link WebElement} widget itself, or null if there is no reference to a widget
	 * <p>
	 * 	 Note: I could have used a Null object design pattern or throw an exception but I'm simplifying the
	 * 		   method's usage. Besides, we want the test case to fail immediately if the widget isn't found.
	 * </p>
	 */
	public WebElement findElement(WebDriver driver, By by){
		try{
			waitForPresenceOfWidget(driver, by);
			return driver.findElement(by);
		}catch(Exception e){
			AutomationHelper.writeToLogsAsIs("\n***Failed to interact with Widget identified by"
					+ "\n\tSelector: "+by.toString()+"***");
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
		}//catch
		return null;
	}//findElement

	/**
	 * Finds a group of widgets on the page
	 * @param driver crawling the page
	 * @param by the XPATH or CSS locator for the widget group
	 * @return reference to @see{com.java.util.List} of {@link WebElement} widgets , or null if there is no 
	 * reference to a widget
	 * <p>
	 * 	 Note: I could have used a Null object design pattern or throw an exception but I'm simplifying the
	 * 		   method's usage. Besides, we want the test case to fail immediately if the widget isn't found.
	 * </p>
	 */
	public List<WebElement> findElements(WebDriver driver, By by){
		try{
			waitForPresenceOfWidget(driver, by);
			List<WebElement> els = driver.findElements(by);
			return els;
		}catch(Exception e){
			AutomationHelper.writeToLogsAsIs("\n***Failed to interact with Widget identified by"
					+ "\n\tSelector: "+by.toString()+"***");
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
		}//catch
		return null;
	}

	/**
	 * Method facilitates clicking a widget
	 * @param driver crawling the page
	 * @param selector CSS or XPath to the widget that's being clicked
	 */
	protected void clickElement(WebDriver driver, By selector){
		try{
			if(isElementPresent(driver, selector)){
				highlightElement(driver,driver.findElement(selector));
				AutomationHelper.writeToLogsAsIs("Clicking Widget: "+selector.toString());
				driver.findElement(selector).click();
			}//if present
		}catch(Exception e){	
			AutomationHelper.writeToLogsAsIs("\n***Failed to interact with Widget identified by"
					+ "\n\tSelector: "+selector.toString()+"***");
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
		}//catch
		finally{}
	}
		
	/**
	 * Utility method instructs the WebDriver object to poll the DOM and wait for the widget to show up. Once found, 
	 * the wait is set for the life of the WebDriver instance. The caller should check null when this method is called.
	 * @param driver crawling the page
	 * @param locator CSS or XPath selector used to find the widget
	 * @return reference to the {@link WebElement} widget itself, , or null if there is no reference to a widget
	 * <p>
	 * 	 Note: I could have used a Null object design pattern or throw an exception but I'm simplifying the
	 * 		   method's usage. Besides, we want the test case to fail immediately if the widget isn't found.
	 * </p>
	 */
	protected WebElement doImplicitWait(WebDriver driver, By locator){
		driver.manage().timeouts().implicitlyWait(IMPL_WAIT, TimeUnit.SECONDS);
		//driver.get("a URL that delays the loading, if bringing 3rd party data");
		try{
			return driver.findElement(locator);
		}catch(Exception e){
			AutomationHelper.writeToLogsAsIs("\n***Failed to locate Widget identified by"
					+ "\n\tSelector: "+locator.toString()+"***");
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
		}//catch
		return null;
	}
	
	/**
	 * Usually for debugging purposes, allow a page to highlight the widget it's working with
	 * @param driver reference to the WebDriver crawling the page
	 * @param widget XPath or CSS locator of the widget the driver is working with
	 */
	protected void extraHighlightWidget(WebDriver driver, By widget){
		WebElement element = driver.findElement(widget);
		for (int i=0; i<28; i++){
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
							element, "color:yellow; border:12px solid yellow; border-style: dashed;");
			js.executeScript("arguments[0].setAttribute('style', arguments[1]);",
								element, "");
		}
	}
	

	/**
	 * Method facilitates clearing a field (field or text area)
	 * @param driver crawling the page
	 * @param selector CSS or XPath to the widget that's being cleared of text
	 */
	protected void clearField(WebDriver driver, By selector){
		try{
			if(isElementPresent(driver, selector)){
				driver.findElement(selector).clear();
			}//if present
		}catch(Exception e){
			AutomationHelper.writeToLogsAsIs("\n***Failed to interact with Widget identified by"
					+ "\n\tSelector: "+selector.toString()+"***");
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
			// 
				//TestCaseConstants.SCREENSHOT_PATH,"clearFieldFailure");
		}//catch
	}
	/**
	 * Method facilitates the sending of text to a widget (clears field first)
	 * @param selector be it XPath or CSS, this selects the widget
	 * @param text to be send to the widget
	 */
	protected void sendText(WebDriver driver, By selector, String text){
		try{
			waitForIt(driver,selector);
			clearField(driver, selector);
			AutomationHelper.writeToLogsAsIs("Send text to Widget: "+selector.toString());
			findElement(driver, selector).sendKeys(text);
		}catch(Exception e){
			AutomationHelper.writeToLogsAsIs("\n***Failed to interact with Widget identified by"
					+ "\n\tSelector: "+selector.toString()+"***");
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);	
		}//catch
		finally{}
	}
	
	/**
	 * Scroll browser window to Point(0,0)
	 */
	//* refactor @param driver reference to driver crawling the page if needed
	protected void scrollWindowToTop(){			
		((JavascriptExecutor) driver).executeScript("window.scrollTo(0,0)");
	}
	
	/**
	 * Clicks on a variable number of nested widgets
	 * @param driver traverses the page
	 * @param widgets a variable number of widgets
	 * @return reference to the WebDriver object
	 */
	protected WebDriver clickEnsuingWidgets(WebDriver driver, By... widgets) {
		Actions builder = new Actions(driver);
		for(int i=0; i< widgets.length; i++) {
			builder.click(driver.findElement(widgets[i]));
		}//for
		
		Action out = builder.build();
		out.perform();
		return driver;
	}
	
	/**
	 * Allows the page to take a screenshot. A time stamp is added  
	 * @param driver reference to the WebDriver crawling the page
	 * @param path where to save the screenshot
	 * @param testClassName name of test case class that took the screenshot
	 */
	public static void takeAScreenshot(WebDriver driver, String path,
										String testClassName){
		/*
		WebDriver augmentedDriver = new Augmenter().augment(driver);
		File screenshot = 
			((TakesScreenshot)augmentedDriver).getScreenshotAs(OutputType.FILE);
			*/
		File screenshot = 
				((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			FileUtils.copyFile(screenshot, 
					new File(path+"screenshot-"+
							testClassName+"-"+
							AutomationHelper.getRandomNumberInt(1000000)+".png"));
		} catch (IOException e) {
			AutomationHelper.logExceptionAndThrowable("\n** Couldn't save file in the "
							+ "desired location **\n"+e.getMessage(), e);
			e.printStackTrace();
		}
	}
	
	/**
	 * Allows for the taking of a screenshot of the entire screen. I'm capturing
	 * all the exceptions in this class --seeing that this is for test automation
	 * purposes; else, I'd let the caller process said exceptions
	 * @param filename the name of file(and location) to store the picture as
	 */
	public static void takeScreenshotOfEntireScreen(String filename){
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		Rectangle screenRectangle = new Rectangle(screenSize);
		Robot robot = null;
		try {
			robot = new Robot();
		} catch (AWTException e1) {
			/*
			 * AWTException is thrown if the current platform configuration 
			 * does not allow input control (ex. these X-Windows types)
			 */
			AutomationHelper.logExceptionAndThrowable("Platform configuration does not allow input control "
					+ "(ex. X-Windows):\n"+e1.getLocalizedMessage(), e1);
			e1.printStackTrace();
		}
		BufferedImage image = robot.createScreenCapture(screenRectangle);
		try {
			ImageIO.write(image, "png", new File(filename));
		} catch (IOException e) {
			AutomationHelper.logExceptionAndThrowable(e.getMessage(),e);
			e.printStackTrace();
		}
	}
	
	/**
	 * Wait for element to be present in the DOM
	  * @param driver WebDriver that's crawling the page
	 * @param by the selector to get at the widget
	 *@return reference to the {@link WebElement} widget, , or null if there is no reference to a widget
	 * <p>
	 * 	 Note: I could have used a Null object design pattern or throw an exception but I'm simplifying the
	 * 		   method's usage. Besides, we want the test case to fail immediately if the widget isn't found.
	 * </p>
	 */
	protected WebElement waitForIt(WebDriver driver, By by){
		WebDriverWait wait = new WebDriverWait(driver, WAIT_TIME, POLL_TIME);
		try{
			//WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(by));
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(by));
		return element;
		}catch(Exception e){
			AutomationHelper.writeToLogsAsIs("\n*** Failed to interact with Widget identified by"
					+ "\n\tSelector: "+by.toString()+"***");
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
		}//catch
		finally{}
		return null;
	}
	
	/**
	 * Sleep in the thread for (time) seconds
	 * @param time how long (in seconds) to wait
	 */
	public static void waitForAwhile(long time){
		boolean interrupted = false;
		try{
			Thread.sleep(time);
		} catch (InterruptedException e) { 
			interrupted = true; // fall through and retry 
			AutomationHelper.logStackTrace("Thread Error: "+e.getMessage());
		} 
		finally{ 
			if (interrupted) Thread.currentThread().interrupt(); 
		}
		
	}
	
	/**
	 * Special case method that asserts whether widgets are present by checking the size of the widget:
	 * if greater than 0 the widget is probably there ... it doesn't have to be enabled, just present 
	 * sufficient for checking if present purposes 
	 * @param driver crawling the page
	 * @param locator CSS,or XPATH locator used to find the widgets
	 * @return true if widgets are on the page
	 */
	protected boolean areElementsSized(WebDriver driver, By locator){
		try{
			List<WebElement> els = findElements(driver, locator);
			for(WebElement el: els) {
				highlightWidget(driver, el);
			}
			return (driver.findElements(locator).size() > 0);
		}catch (Throwable e){
			AutomationHelper.writeToLogsAsIs("\n***Failed to interact with Widget identified by"
					+ "\n\tSelector: "+locator.toString()+"***");
			AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
			return false;
		}
	}
	
	/**
	 * Assert whether the given resource is download-able
	 * @param driver crawling the page
	 * @param url URL of resource
	 * @return true if the file can be downloaded
	 * @throws MalformedURLException if URL is malformed
	 * @throws IOException if resource doesn't exist
	 */
	protected boolean isDownloadAble(WebDriver driver, String url) throws IOException {
		HttpURLConnection.setFollowRedirects(false);//false for now
		HttpURLConnection con = (HttpURLConnection) new URL(url).openConnection();
		con.setRequestMethod("HEAD");
		return (con.getResponseCode() == HttpURLConnection.HTTP_OK); // 200 if file exists
	}
	/**
	 * Gets specific number of options from the multiple select dropdown widget (overloaded to be thread-safe). A 
	 * RentrantLock is being used seeing that this can be updated asynchronously
	 * @param driver crawling the page
	 * @param select the XSS/CSS locator to the dropdown
	 * @param num the number of options to select
	 * @return reference to @see{com.java.util.List} of {@link WebElement} widgets, the selected options from the dropdown
	 */
	public List<WebElement> getSelectOptions(WebDriver driver, By select, int num){
		Select opts = new Select(driver.findElement(select));
		List<WebElement> all = opts.getOptions();
		List<WebElement> selected = new ArrayList<WebElement>();
		readWriteLock.readLock().unlock();//stop reading
		readWriteLock.writeLock().lock();//acquire write lock
		try {
			for(int i=0; i< num; i++){
				selected.add(all.get(i));
			}
		}finally {
			readWriteLock.writeLock().unlock();//finished with the write lock
		}
		return selected;
	}
 
	/**
	 * Performs a HEAD request
	 * @param driver traversing the page
	 * @param headUrl URL to make the HEAD against
	 * @return the response message
	 */
	protected String performHeadRequest(WebDriver driver, String headUrl) {
		 HttpURLConnection urlConnection = null;
		 String response="";
	    System.setProperty("http.keepAlive", "false");
	    try {
	        URL url = new URL(headUrl);
	        urlConnection = (HttpURLConnection) url.openConnection();
	        urlConnection.setRequestMethod("HEAD");
	        response = urlConnection.getResponseMessage();
	        urlConnection.getInputStream().close();
	    } catch (IOException e) {
	        e.printStackTrace();
	        AutomationHelper.logExceptionAndThrowable(e.getMessage(), e);
	    } finally {
	        if (urlConnection != null) {
	            urlConnection.disconnect();
	        }
	    }
	    
	    return response;
	}
	
	/*
	* OMMITTED METHODS BELOW, but I hope the point has been made: this class has all the functionality
	* that are common to page objects extending this class
	*/
	
}


