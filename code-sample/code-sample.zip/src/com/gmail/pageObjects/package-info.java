/**
 * 
 */
/**
 * The page object model is housed in this package
 * @author IRiley
 *
 */
package com.gmail.pageObjects;