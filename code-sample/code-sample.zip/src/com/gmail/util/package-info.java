/**
 * 
 */
/**
 * Utility methods
 * @author IRiley
 *
 */
package com.gmail.util;