/**
 * 
 */
/**
 * The target nodes
 * @author IRiley
 *
 */
package com.gmail.grid.factory.nodes;